package ir.university.dresscode

import java.util.Date

data class Student(
    val id: String, val sid: String, val nid: String,
    val first: String, val last: String, val major: String,
) {
    val fullName get() = "$first $last".trim()
    /** متن یکسان‌شده برای جستجو */
    val hay: String = T.norm("$first $last $sid $nid")
    fun toMap() = mapOf("sid" to sid, "nid" to nid, "first" to first, "last" to last, "major" to major)
}

data class Violation(
    val id: String, val studentId: String, val sid: String, val nid: String,
    val first: String, val last: String, val type: String, val note: String,
    val date: Date, val by: String, val uid: String,
)

val VIOLATION_TYPES = listOf("عدم رعایت حجاب", "پوشش نامناسب", "آرایش نامتعارف", "لباس تنگ یا کوتاه", "شلوارک / آستین کوتاه", "سایر")

object Importer {
    private fun key(h: String) = T.norm(h).replace(Regex("[\\s_\\-.]"), "")
    private val MAP = listOf(
        "full" to listOf("نامونامخانوادگی", "fullname"),
        "last" to listOf("نامخانوادگی", "فامیل", "فامیلی", "lastname", "family", "surname"),
        "sid" to listOf("شمارهدانشجویی", "شمارهدانشجو", "کددانشجویی", "studentid", "studentno", "stdno", "sid"),
        "nid" to listOf("کدملی", "شمارهملی", "nationalid", "nationalcode", "nid"),
        "first" to listOf("نام", "firstname", "first", "name"),
        "major" to listOf("رشته", "رشتهتحصیلی", "major", "field"),
    )

    /** ردیف اول = سرستون‌ها. اگر ستون شماره دانشجویی یا کد ملی پیدا نشود، لیست خالی برمی‌گردد. */
    fun toStudents(rows: List<List<String>>): List<Student> {
        if (rows.size < 2) return emptyList()
        val headers = rows[0].map { key(it) }
        val col = mutableMapOf<String, Int>()
        for ((field, keys) in MAP) {
            val idx = headers.indices.firstOrNull { it !in col.values && headers[it] in keys }
            if (idx != null) col[field] = idx
        }
        if (col["sid"] == null && col["nid"] == null) return emptyList()
        fun cell(r: List<String>, f: String) = col[f]?.let { r.getOrNull(it) }?.trim() ?: ""
        val seen = HashSet<String>()
        return rows.drop(1).mapNotNull { r ->
            var first = cell(r, "first"); var last = cell(r, "last")
            if (first.isEmpty() && last.isEmpty()) {
                val p = cell(r, "full").split(Regex("\\s+")).filter { it.isNotEmpty() }
                first = p.firstOrNull() ?: ""; last = p.drop(1).joinToString(" ")
            }
            val sid = T.norm(cell(r, "sid"))
            var nid = T.norm(cell(r, "nid"))
            if (nid.isNotEmpty() && nid.all { it.isDigit() } && nid.length < 10) nid = nid.padStart(10, '0') // صفرهای اول که اکسل حذف کرده
            val id = (sid.ifEmpty { nid }).replace("/", "-")
            if (id.isEmpty() || !seen.add(id)) null
            else Student(id, sid, nid, first, last, cell(r, "major"))
        }
    }
}
