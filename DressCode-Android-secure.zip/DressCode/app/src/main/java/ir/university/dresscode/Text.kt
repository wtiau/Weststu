package ir.university.dresscode

import java.util.Calendar
import java.util.Date
import java.util.TimeZone

object T {
    private const val FA = "۰۱۲۳۴۵۶۷۸۹"
    private const val AR = "٠١٢٣٤٥٦٧٨٩"
    private val MONTHS = arrayOf("فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور", "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند")
    private val TEHRAN: TimeZone = TimeZone.getTimeZone("Asia/Tehran")

    /** یکسان‌سازی برای جستجو: ارقام فارسی/عربی، ی و ک عربی، نیم‌فاصله و اعراب */
    fun norm(s: String?): String {
        if (s == null) return ""
        val sb = StringBuilder()
        for (ch in s) {
            val i = FA.indexOf(ch)
            val j = AR.indexOf(ch)
            when {
                i >= 0 -> sb.append('0' + i)
                j >= 0 -> sb.append('0' + j)
                ch == 'ي' -> sb.append('ی')
                ch == 'ك' -> sb.append('ک')
                ch == '\u200c' || ch in '\u064B'..'\u0652' -> {}
                else -> sb.append(ch)
            }
        }
        return sb.toString().trim().replace(Regex("\\s+"), " ").lowercase()
    }

    fun fa(s: String?): String = (s ?: "").map { if (it in '0'..'9') FA[it - '0'] else it }.joinToString("")

    private fun g2j(gy: Int, gm: Int, gd: Int): IntArray {
        val gdm = intArrayOf(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334)
        val gy2 = if (gm > 2) gy + 1 else gy
        var days = 355666 + 365 * gy + (gy2 + 3) / 4 - (gy2 + 99) / 100 + (gy2 + 399) / 400 + gd + gdm[gm - 1]
        var jy = -1595 + 33 * (days / 12053); days %= 12053
        jy += 4 * (days / 1461); days %= 1461
        if (days > 365) { jy += (days - 1) / 365; days = (days - 1) % 365 }
        val jm = if (days < 186) 1 + days / 31 else 7 + (days - 186) / 30
        val jd = 1 + if (days < 186) days % 31 else (days - 186) % 30
        return intArrayOf(jy, jm, jd)
    }

    private fun parts(d: Date): IntArray {
        val c = Calendar.getInstance(TEHRAN).apply { time = d }
        val j = g2j(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
        return intArrayOf(j[0], j[1], j[2], c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE))
    }

    /** «۱ آبان ۱۴۰۵» */
    fun jalali(d: Date): String { val p = parts(d); return fa("${p[2]} ${MONTHS[p[1] - 1]} ${p[0]}") }
    /** «1405/08/01» برای اکسل */
    fun jalaliNum(d: Date): String { val p = parts(d); return "%04d/%02d/%02d".format(p[0], p[1], p[2]) }
    fun time(d: Date): String { val p = parts(d); return "%02d:%02d".format(p[3], p[4]) }
}
