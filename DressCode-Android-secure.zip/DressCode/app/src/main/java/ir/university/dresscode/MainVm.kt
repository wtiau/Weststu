package ir.university.dresscode

import android.content.ContentResolver
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.util.Date

class MainVm : ViewModel() {
    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()

    var user by mutableStateOf<FirebaseUser?>(auth.currentUser)
        private set
    var students by mutableStateOf<List<Student>>(emptyList())
        private set
    var violations by mutableStateOf<List<Violation>>(emptyList())
        private set
    var busy by mutableStateOf(false)
        private set
    var message by mutableStateOf<String?>(null)

    private var reg: ListenerRegistration? = null

    init {
        auth.addAuthStateListener { a ->
            user = a.currentUser
            if (a.currentUser != null) start() else stop()
        }
    }

    private fun start() {
        if (reg != null) return
        viewModelScope.launch { loadStudents() }
        // تخلفات به‌صورت زنده بین همه‌ی مأمورها همگام می‌شود (آفلاین هم ثبت و بعداً ارسال می‌شود)
        reg = db.collection("violations").orderBy("date", Query.Direction.DESCENDING)
            .addSnapshotListener { snap, _ ->
                if (snap != null) violations = snap.documents.map { d ->
                    Violation(
                        id = d.id, studentId = d.getString("studentId") ?: "",
                        sid = d.getString("sid") ?: "", nid = d.getString("nid") ?: "",
                        first = d.getString("first") ?: "", last = d.getString("last") ?: "",
                        type = d.getString("type") ?: "", note = d.getString("note") ?: "",
                        date = d.getTimestamp("date")?.toDate() ?: Date(),
                        by = d.getString("by") ?: "", uid = d.getString("uid") ?: "",
                    )
                }
            }
    }

    private fun stop() { reg?.remove(); reg = null; students = emptyList(); violations = emptyList() }

    suspend fun loadStudents() {
        try {
            val snap = db.collection("students").get().await()
            students = snap.documents.map { d ->
                Student(d.id, d.getString("sid") ?: "", d.getString("nid") ?: "",
                    d.getString("first") ?: "", d.getString("last") ?: "", d.getString("major") ?: "")
            }.sortedBy { it.last }
        } catch (e: Exception) { message = "خواندن لیست دانشجویان ناموفق بود" }
    }

    fun login(email: String, pass: String) {
        if (email.isBlank() || pass.isBlank()) { message = "ایمیل و رمز را وارد کنید"; return }
        viewModelScope.launch {
            busy = true
            try { auth.signInWithEmailAndPassword(email.trim(), pass).await() }
            catch (e: Exception) { message = "ایمیل یا رمز عبور اشتباه است" }
            busy = false
        }
    }

    fun logout() = auth.signOut()

    fun search(q: String): List<Student> {
        val parts = T.norm(q).split(" ").filter { it.isNotEmpty() }
        if (parts.isEmpty()) return emptyList()
        return students.asSequence().filter { s -> parts.all { s.hay.contains(it) } }.take(60).toList()
    }

    fun importExcel(resolver: ContentResolver, uri: Uri) {
        viewModelScope.launch {
            busy = true
            try {
                val list = withContext(Dispatchers.IO) {
                    Importer.toStudents(resolver.openInputStream(uri)!!.use { Xlsx.read(it) })
                }
                if (list.isEmpty()) {
                    message = "ستون «شماره دانشجویی» یا «کد ملی» پیدا نشد"
                } else {
                    list.chunked(400).forEach { chunk ->
                        val b = db.batch()
                        chunk.forEach { b.set(db.collection("students").document(it.id), it.toMap()) }
                        b.commit().await()
                    }
                    loadStudents()
                    message = "${T.fa(list.size.toString())} دانشجو وارد شد"
                }
            } catch (e: FirebaseFirestoreException) {
                message = if (e.code == FirebaseFirestoreException.Code.PERMISSION_DENIED)
                    "فقط مدیر می‌تواند لیست دانشجویان را وارد کند" else "ذخیره در سرور ناموفق بود"
            } catch (e: Exception) {
                message = "فایل قابل خواندن نیست (فقط فرمت xlsx)"
            } finally { busy = false }
        }
    }

    fun addViolation(s: Student, type: String, note: String) {
        val u = user ?: return
        val data = hashMapOf(
            "studentId" to s.id, "sid" to s.sid, "nid" to s.nid, "first" to s.first, "last" to s.last,
            "type" to type, "note" to note.trim(), "date" to Timestamp.now(),
            "by" to (u.email ?: ""), "uid" to u.uid,
        )
        db.collection("violations").add(data).addOnFailureListener { message = "ثبت تخلف ناموفق بود" }
    }

    fun deleteViolation(v: Violation) {
        db.collection("violations").document(v.id).delete()
            .addOnFailureListener { message = "فقط ثبت‌کننده یا مدیر می‌تواند حذف کند" }
    }

    fun exportExcel(resolver: ContentResolver, uri: Uri) {
        viewModelScope.launch {
            try {
                val groups = violations.groupBy { it.studentId }.values.sortedByDescending { it.size }
                val summary = listOf(listOf("شماره دانشجویی", "کد ملی", "نام", "نام خانوادگی", "تعداد تخلف", "آخرین تخلف")) +
                    groups.map { g -> val v = g.first(); listOf(v.sid, v.nid, v.first, v.last, g.size.toString(), T.jalaliNum(v.date)) }
                val detail = listOf(listOf("شماره دانشجویی", "کد ملی", "نام", "نام خانوادگی", "نوع تخلف", "توضیحات", "تاریخ", "ساعت", "ثبت‌کننده")) +
                    violations.map { v -> listOf(v.sid, v.nid, v.first, v.last, v.type, v.note, T.jalaliNum(v.date), T.time(v.date), v.by) }
                withContext(Dispatchers.IO) {
                    resolver.openOutputStream(uri)!!.use { Xlsx.write(it, listOf("خلاصه متخلفین" to summary, "جزئیات تخلفات" to detail)) }
                }
                message = "فایل اکسل ذخیره شد"
            } catch (e: Exception) { message = "ساخت فایل اکسل ناموفق بود" }
        }
    }
}
