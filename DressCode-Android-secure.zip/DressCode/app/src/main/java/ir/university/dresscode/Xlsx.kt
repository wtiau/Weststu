package ir.university.dresscode

import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.io.InputStream
import java.io.OutputStream
import java.math.BigDecimal
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** خواندن و نوشتن xlsx بدون کتابخانه‌ی سنگین (Apache POI روی اندروید دردسر دارد). */
object Xlsx {

    fun read(input: InputStream): List<List<String>> {
        val files = HashMap<String, ByteArray>()
        ZipInputStream(input).use { z ->
            var e = z.nextEntry
            while (e != null) {
                if (e.name == "xl/sharedStrings.xml" || e.name.startsWith("xl/worksheets/sheet")) files[e.name] = z.readBytes()
                e = z.nextEntry
            }
        }
        val sheetName = files.keys.filter { it.startsWith("xl/worksheets/sheet") && it.endsWith(".xml") }
            .minByOrNull { it.filter(Char::isDigit).toIntOrNull() ?: 999 }
            ?: throw IllegalArgumentException("not xlsx")
        val shared = files["xl/sharedStrings.xml"]?.let { readShared(it) } ?: emptyList()
        return readSheet(files[sheetName]!!, shared)
    }

    private fun parser(b: ByteArray): XmlPullParser =
        Xml.newPullParser().apply { setInput(ByteArrayInputStream(b), "UTF-8") }

    private fun readShared(b: ByteArray): List<String> {
        val out = ArrayList<String>()
        val p = parser(b)
        var sb: StringBuilder? = null
        var inT = false
        while (p.next() != XmlPullParser.END_DOCUMENT) {
            when (p.eventType) {
                XmlPullParser.START_TAG -> when (p.name) { "si" -> sb = StringBuilder(); "t" -> inT = true; "rPh" -> inT = false }
                XmlPullParser.TEXT -> if (inT) sb?.append(p.text)
                XmlPullParser.END_TAG -> when (p.name) { "t" -> inT = false; "si" -> { out.add(sb.toString()); sb = null } }
            }
        }
        return out
    }

    private fun colIndex(ref: String): Int {
        var n = 0
        for (ch in ref) { if (ch !in 'A'..'Z') break; n = n * 26 + (ch - 'A' + 1) }
        return n - 1
    }

    private fun readSheet(b: ByteArray, shared: List<String>): List<List<String>> {
        val rows = ArrayList<List<String>>()
        val p = parser(b)
        var row: ArrayList<String>? = null
        var col = 0; var type = ""; var value = StringBuilder(); var inV = false
        while (p.next() != XmlPullParser.END_DOCUMENT) {
            when (p.eventType) {
                XmlPullParser.START_TAG -> when (p.name) {
                    "row" -> row = ArrayList()
                    "c" -> {
                        val r = p.getAttributeValue(null, "r")
                        col = if (r != null) colIndex(r) else (row?.size ?: 0)
                        type = p.getAttributeValue(null, "t") ?: ""
                        value = StringBuilder()
                    }
                    "v", "t" -> inV = true
                }
                XmlPullParser.TEXT -> if (inV) value.append(p.text)
                XmlPullParser.END_TAG -> when (p.name) {
                    "v", "t" -> inV = false
                    "c" -> row?.let { rw ->
                        val raw = value.toString()
                        val text = when (type) {
                            "s" -> shared.getOrNull(raw.trim().toIntOrNull() ?: -1) ?: ""
                            "inlineStr", "str" -> raw
                            "b" -> raw
                            else -> number(raw)
                        }
                        while (rw.size < col) rw.add("")
                        if (rw.size == col) rw.add(text) else rw[col] = text
                    }
                    "row" -> { row?.let { if (it.any { c -> c.isNotBlank() }) rows.add(it) }; row = null }
                }
            }
        }
        return rows
    }

    /** 4.0112345E7 → 40112345 */
    private fun number(raw: String): String = try {
        BigDecimal(raw.trim()).stripTrailingZeros().toPlainString()
    } catch (e: Exception) { raw }

    // ---------- نوشتن ----------

    private fun esc(s: String) = buildString {
        for (ch in s) when {
            ch == '&' -> append("&amp;"); ch == '<' -> append("&lt;"); ch == '>' -> append("&gt;"); ch == '"' -> append("&quot;")
            ch < ' ' && ch != '\t' && ch != '\n' && ch != '\r' -> {}
            else -> append(ch)
        }
    }

    private fun colName(i: Int): String { var n = i + 1; var s = ""; while (n > 0) { val m = (n - 1) % 26; s = ('A' + m) + s; n = (n - 1) / 26 }; return s }

    private fun sheetXml(rows: List<List<String>>): String = buildString {
        append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">""")
        append("""<sheetViews><sheetView rightToLeft="1" workbookViewId="0"/></sheetViews>""")
        val nCols = rows.maxOfOrNull { it.size } ?: 0
        if (nCols > 0) append("<cols><col min=\"1\" max=\"$nCols\" width=\"20\" customWidth=\"1\"/></cols>")
        append("<sheetData>")
        rows.forEachIndexed { ri, r ->
            append("<row r=\"${ri + 1}\">")
            r.forEachIndexed { ci, v ->
                append("<c r=\"${colName(ci)}${ri + 1}\" t=\"inlineStr\"${if (ri == 0) " s=\"1\"" else ""}><is><t xml:space=\"preserve\">${esc(v)}</t></is></c>")
            }
            append("</row>")
        }
        append("</sheetData></worksheet>")
    }

    /** sheets: نام برگه → ردیف‌ها (ردیف اول سرستون) */
    fun write(out: OutputStream, sheets: List<Pair<String, List<List<String>>>>) {
        val n = sheets.size
        val files = linkedMapOf(
            "[Content_Types].xml" to buildString {
                append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>""")
                for (i in 1..n) append("""<Override PartName="/xl/worksheets/sheet$i.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>""")
                append("</Types>")
            },
            "_rels/.rels" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>""",
            "xl/workbook.xml" to buildString {
                append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><bookViews><workbookView rightToLeft="1"/></bookViews><sheets>""")
                sheets.forEachIndexed { i, s -> append("<sheet name=\"${esc(s.first.take(31))}\" sheetId=\"${i + 1}\" r:id=\"rId${i + 1}\"/>") }
                append("</sheets></workbook>")
            },
            "xl/_rels/workbook.xml.rels" to buildString {
                append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">""")
                for (i in 1..n) append("""<Relationship Id="rId$i" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet$i.xml"/>""")
                append("""<Relationship Id="rId${n + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>""")
            },
            "xl/styles.xml" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="11"/><name val="Tahoma"/></font><font><b/><sz val="11"/><name val="Tahoma"/></font></fonts><fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills><borders count="1"><border/></borders><cellStyleXfs count="1"><xf/></cellStyleXfs><cellXfs count="2"><xf fontId="0"/><xf fontId="1" applyFont="1"/></cellXfs></styleSheet>""",
        )
        sheets.forEachIndexed { i, s -> files["xl/worksheets/sheet${i + 1}.xml"] = sheetXml(s.second) }
        ZipOutputStream(out).use { z ->
            for ((name, content) in files) { z.putNextEntry(ZipEntry(name)); z.write(content.toByteArray(Charsets.UTF_8)); z.closeEntry() }
        }
    }
}
