@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package ir.university.dresscode

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.delay
import java.util.Date

val Ink = Color(0xFF2B2326)
val Paper = Color(0xFFFBF8F8)
val CardC = Color(0xFFF4EFF0)
val Accent = Color(0xFFAA3F5D)
val Teal = Color(0xFF2E92A2)
val Muted = Color(0xFF6D5D62)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // جلوگیری از اسکرین‌شات و نمایش محتوا در لیست برنامه‌های اخیر (کد ملی دانشجوها)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        setContent {
            val vm: MainVm = viewModel()
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme(colorScheme = lightColorScheme(primary = Accent, onPrimary = Color.White, background = Paper, surface = Paper, onSurface = Ink)) {
                    val snack = remember { SnackbarHostState() }
                    LaunchedEffect(vm.message) { vm.message?.let { snack.showSnackbar(it); vm.message = null } }
                    Scaffold(containerColor = Paper, snackbarHost = { SnackbarHost(snack) }) { pad ->
                        Box(Modifier.padding(pad)) { if (vm.user == null) LoginScreen(vm) else MainScreen(vm) }
                    }
                }
            }
        }
    }
}

@Composable
fun Header(title: String, right: String = "", onBack: (() -> Unit)? = null) {
    Column(Modifier.fillMaxWidth().background(Ink).padding(horizontal = 20.dp, vertical = 18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = Paper, fontSize = 26.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
            if (onBack != null) IconButton(onClick = onBack) { Icon(Icons.Default.Close, "بستن", tint = Paper) }
            else Text(right, color = Color(0xFFD9C9CE), fontSize = 14.sp)
        }
        Spacer(Modifier.height(10.dp))
        Box(Modifier.size(56.dp, 6.dp).background(Accent))
    }
}

@Composable
fun LoginScreen(vm: MainVm) {
    var email by rememberSaveable { mutableStateOf("") }
    var pass by rememberSaveable { mutableStateOf("") }
    Column(Modifier.fillMaxSize()) {
        Header("دفتر پوشش")
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("ورود مأمور", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
            OutlinedTextField(email, { email = it }, label = { Text("ایمیل") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email), modifier = Modifier.fillMaxWidth())
            OutlinedTextField(pass, { pass = it }, label = { Text("رمز عبور") }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password), modifier = Modifier.fillMaxWidth())
            Button(onClick = { vm.login(email, pass) }, enabled = !vm.busy, shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().height(52.dp)) {
                if (vm.busy) CircularProgressIndicator(Modifier.size(22.dp), color = Color.White, strokeWidth = 2.dp)
                else Text("ورود", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
            Text("حساب‌ها را مدیر در کنسول Firebase می‌سازد.", color = Muted, fontSize = 14.sp)
        }
    }
}

@Composable
fun MainScreen(vm: MainVm) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var openId by rememberSaveable { mutableStateOf<String?>(null) }
    val counts = remember(vm.violations) { vm.violations.groupingBy { it.studentId }.eachCount() }
    val open = openId?.let { id -> vm.students.find { it.id == id } }
    if (open != null) {
        BackHandler { openId = null }
        StudentScreen(vm, open) { openId = null }
        return
    }
    Column(Modifier.fillMaxSize()) {
        Header("دفتر پوشش", "${T.fa(vm.students.size.toString())} دانشجو")
        Box(Modifier.weight(1f)) {
            when (tab) {
                0 -> SearchTab(vm, counts) { openId = it }
                1 -> ViolatorsTab(vm, counts) { openId = it }
                else -> DataTab(vm)
            }
        }
        NavigationBar(containerColor = Paper) {
            listOf(Triple("جستجو", Icons.Default.Search, 0), Triple("متخلفین", Icons.Default.Warning, 1), Triple("داده‌ها", Icons.Default.Settings, 2))
                .forEach { (label, icon, i) ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(icon, label) },
                        label = { Text(label, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(selectedIconColor = Accent, selectedTextColor = Accent, indicatorColor = CardC))
                }
        }
    }
}

@Composable
fun StudentRow(s: Student, count: Int, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(CardC).clickable(onClick = onClick).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(48.dp).clip(RoundedCornerShape(10.dp)).background(if (count > 0) Accent else Teal.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center) {
            Text(if (count > 0) T.fa(count.toString()) else s.first.take(1).ifEmpty { "؟" },
                color = if (count > 0) Color.White else Teal, fontWeight = FontWeight.Black, fontSize = 18.sp)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(s.fullName, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 1)
            Text("${T.fa(s.sid.ifEmpty { "—" })}   |   کد ملی ${T.fa(s.nid.ifEmpty { "—" })}", color = Muted, fontSize = 14.sp, maxLines = 1)
        }
    }
}

@Composable
fun SearchTab(vm: MainVm, counts: Map<String, Int>, onOpen: (String) -> Unit) {
    var q by rememberSaveable { mutableStateOf("") }
    val res = remember(q, vm.students) { vm.search(q) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        OutlinedTextField(q, { q = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("شماره دانشجویی، کد ملی یا نام") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            trailingIcon = { if (q.isNotEmpty()) IconButton(onClick = { q = "" }) { Icon(Icons.Default.Close, "پاک کردن") } },
            shape = RoundedCornerShape(12.dp))
        Spacer(Modifier.height(10.dp))
        when {
            vm.students.isEmpty() -> Empty("هنوز لیستی وارد نشده", "از تب «داده‌ها» فایل اکسل را وارد کنید.")
            q.isBlank() -> Text("مثلاً «احمدی»، «۴۰۱۱» یا «مریم احمدی»", color = Muted, fontSize = 14.sp, modifier = Modifier.fillMaxWidth().padding(top = 12.dp))
            res.isEmpty() -> Text("دانشجویی پیدا نشد", color = Muted, fontSize = 14.sp)
            else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(res, key = { it.id }) { s -> StudentRow(s, counts[s.id] ?: 0) { onOpen(s.id) } }
            }
        }
    }
}

@Composable
fun ViolatorsTab(vm: MainVm, counts: Map<String, Int>, onOpen: (String) -> Unit) {
    val ctx = LocalContext.current
    val saver = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    ) { uri -> if (uri != null) vm.exportExcel(ctx.contentResolver, uri) }
    val list = remember(vm.students, counts) { vm.students.filter { (counts[it.id] ?: 0) > 0 }.sortedByDescending { counts[it.id] } }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        if (list.isEmpty()) { Empty("پرونده‌ها پاک است", "هنوز تخلفی ثبت نشده."); return@Column }
        Row(verticalAlignment = Alignment.Bottom) {
            Column(Modifier.weight(1f)) {
                Text(T.fa(list.size.toString()), color = Accent, fontSize = 44.sp, fontWeight = FontWeight.Black, lineHeight = 44.sp)
                Text("متخلف · ${T.fa(vm.violations.size.toString())} تخلف", color = Muted, fontSize = 14.sp)
            }
            Button(onClick = { saver.launch("motekhalefin-${T.jalaliNum(Date()).replace("/", "-")}.xlsx") },
                colors = ButtonDefaults.buttonColors(containerColor = Ink), shape = RoundedCornerShape(12.dp)) {
                Text("خروجی اکسل", fontWeight = FontWeight.Bold)
            }
        }
        Spacer(Modifier.height(14.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(list, key = { it.id }) { s -> StudentRow(s, counts[s.id] ?: 0) { onOpen(s.id) } }
        }
    }
}

@Composable
fun DataTab(vm: MainVm) {
    val ctx = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importExcel(ctx.contentResolver, uri)
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("لیست دانشجویان", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Accent.copy(alpha = 0.06f))
            .border(2.dp, Accent, RoundedCornerShape(16.dp)).clickable(enabled = !vm.busy) { picker.launch(arrayOf("*/*")) }
            .padding(vertical = 28.dp), contentAlignment = Alignment.Center) {
            if (vm.busy) CircularProgressIndicator(color = Accent)
            else Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("انتخاب فایل اکسل (xlsx)", color = Accent, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text("دانشجویان تکراری به‌روز می‌شوند", color = Muted, fontSize = 14.sp)
            }
        }
        Text("ستون‌ها: شماره دانشجویی، کد ملی، نام، نام خانوادگی، رشته (اختیاری)", color = Muted, fontSize = 14.sp)
        HorizontalDivider(color = CardC)
        Text("حساب کاربری", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
        Text(vm.user?.email ?: "", color = Muted, fontSize = 14.sp)
        OutlinedButton(onClick = { vm.logout() }, shape = RoundedCornerShape(12.dp)) { Text("خروج", color = Color(0xFFD85A44)) }
    }
}

@Composable
fun StudentScreen(vm: MainVm, s: Student, onClose: () -> Unit) {
    var type by rememberSaveable { mutableStateOf(VIOLATION_TYPES[0]) }
    var note by rememberSaveable { mutableStateOf("") }
    var stamp by remember { mutableIntStateOf(0) }
    var showStamp by remember { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<Violation?>(null) }
    val history = remember(vm.violations, s.id) { vm.violations.filter { it.studentId == s.id } }
    LaunchedEffect(stamp) { if (stamp > 0) { showStamp = true; delay(1600); showStamp = false } }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Box {
            Column {
                Header(s.fullName, onBack = onClose)
                Row(Modifier.fillMaxWidth().background(Ink).padding(start = 20.dp, end = 20.dp, bottom = 18.dp)) {
                    Column(Modifier.weight(1f)) { Text("شماره دانشجویی", color = Color(0xFFB9A9AE), fontSize = 14.sp); Text(T.fa(s.sid.ifEmpty { "—" }), color = Paper, fontWeight = FontWeight.Bold) }
                    Column(Modifier.weight(1f)) { Text("کد ملی", color = Color(0xFFB9A9AE), fontSize = 14.sp); Text(T.fa(s.nid.ifEmpty { "—" }), color = Paper, fontWeight = FontWeight.Bold) }
                }
                if (s.major.isNotEmpty()) Text(s.major, color = Color(0xFFD9C9CE), fontSize = 14.sp,
                    modifier = Modifier.fillMaxWidth().background(Ink).padding(start = 20.dp, end = 20.dp, bottom = 16.dp))
            }
            // مهر «ثبت شد»
            AnimatedVisibility(showStamp, enter = scaleIn(initialScale = 2.2f) + fadeIn(), exit = fadeOut(),
                modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)) {
                Text("ثبت شد", color = Color(0xFFFF7D9D), fontWeight = FontWeight.Black, fontSize = 18.sp,
                    modifier = Modifier.rotate(-12f).border(3.dp, Color(0xFFFF7D9D), RoundedCornerShape(6.dp)).padding(horizontal = 12.dp, vertical = 4.dp))
            }
        }
        Column(Modifier.padding(20.dp)) {
            Text("نوع تخلف", fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(8.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                VIOLATION_TYPES.forEach { t ->
                    FilterChip(selected = type == t, onClick = { type = t }, label = { Text(t) },
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Accent, selectedLabelColor = Color.White))
                }
            }
            OutlinedTextField(note, { note = it }, placeholder = { Text("توضیحات (اختیاری)") }, minLines = 2,
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp), shape = RoundedCornerShape(12.dp))
            Button(onClick = { vm.addViolation(s, type, note); note = ""; stamp++ }, shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().padding(top = 10.dp).height(54.dp)) {
                Text("ثبت تخلف", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
            }
            Row(Modifier.padding(top = 26.dp, bottom = 8.dp), verticalAlignment = Alignment.Bottom) {
                Text("سوابق", fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                Text(if (history.isEmpty()) "بدون سابقه" else "${T.fa(history.size.toString())} مورد", color = Muted, fontSize = 14.sp)
            }
            history.forEach { v ->
                Row(Modifier.fillMaxWidth().padding(bottom = 8.dp).height(IntrinsicSize.Min).clip(RoundedCornerShape(12.dp)).background(CardC)) {
                    Box(Modifier.width(4.dp).fillMaxHeight().background(Accent))
                    Column(Modifier.weight(1f).padding(12.dp)) {
                        Text(v.type, fontWeight = FontWeight.Bold)
                        if (v.note.isNotEmpty()) Text(v.note, fontSize = 14.sp)
                        Text("${T.jalali(v.date)} · ${T.fa(T.time(v.date))} · ${v.by}", color = Muted, fontSize = 14.sp)
                    }
                    IconButton(onClick = { toDelete = v }) { Icon(Icons.Default.Delete, "حذف", tint = Color(0xFFB7A6AB)) }
                }
            }
        }
    }
    toDelete?.let { v ->
        AlertDialog(onDismissRequest = { toDelete = null },
            title = { Text("حذف تخلف") }, text = { Text("«${v.type}» حذف شود؟") },
            confirmButton = { TextButton(onClick = { vm.deleteViolation(v); toDelete = null }) { Text("حذف", color = Color(0xFFD85A44)) } },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("انصراف") } })
    }
}

@Composable
fun Empty(title: String, sub: String) {
    Column(Modifier.fillMaxWidth().padding(top = 60.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(40.dp, 6.dp).background(Accent))
        Spacer(Modifier.height(14.dp))
        Text(title, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
        Text(sub, color = Muted, fontSize = 14.sp)
    }
}
