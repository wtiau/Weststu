# Firebase قوانین خودش را همراه دارد. حذف لاگ‌ها در نسخه‌ی نهایی:
-assumenosideeffects class android.util.Log { *; }
-keepattributes Signature,*Annotation*
